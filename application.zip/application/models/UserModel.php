<?php


class UserModel extends CI_Model{
    
    public function getdata($id){
        $this->db->select('photo, username, email, dateOfBirth');
        $this->db->from('user');
        $this->db->where('idUser', $id);
        $query=$this->db->get();
        return $query->result_array();
                
    }
    
    public function editdata($id, $username, $email, $date){
        
        $data = array(
        'username' => $username,
        'email' => $email,
        'dateOfBirth' => $date
        );

        $this->db->where('idUser', $id);
        $this->db->update('user', $data);
    }
}
