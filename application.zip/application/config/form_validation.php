<?php
$config['error_prefix'] = '<span class="error text-danger">';
$config['error_suffix'] = '</span>';

