
{messages}
<input type="hidden" name="idc" value="{idConversation}" id="idc">
    <div class="usermsg">
        <div class="user-username">{username}</div>
        <div class="messagecontent">{content}</div>
        
    </div>
{/messages}


 