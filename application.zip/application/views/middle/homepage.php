
<!DOCTYPE html>


<div class="container-fluid">
    <div class="levo">
        
        <div class="img">  
            <?php if($userData[0]['photo'] == NULL){?>
            <img src="<?php echo base_url();?>/photos/profile_image.png" class="img-fluid">
            <?php } else {?>
            <img src="<?php echo base_url().'/photos/'.$userData[0]['photo']?>" class="img-fluid">
            <?php } $user=$this->session->userdata('user');?>
        </div>
        
        <div class="user-info"> 
            
            <?php 
            if($this->input->get('edit')){ 
            ?>
            
            <form name="editForm" method="POST" action="<?php echo site_url("User/editdata")?>">
            <div class="user-data">
            <span class="txt">Username: </span>
                <input type="text" name="user" value="<?php echo $userData[0]['username']?>">
            </div>
            <div class="user-data">
            <span class="txt">Email: </span>
                <input type="email" name="email" value="<?php echo $userData[0]['email']?>">
            </div>
            <div class="user-data">
            <span class="txt">Date of birth: </span>
                <input type="date" name="date" value="<?php echo $userData[0]['dateOfBirth']?>">
            </div>
            <div class="user-data">
                <input type="submit" name="edit" value="Save changes" class="btn btn-primary">
            </div>
            </form>
            
                
            <?php }else{ ?>
            
            <div class="user-data">
            <span class="txt">Username: </span>
            <?php echo $userData[0]['username']?>
            </div>
            <div class="user-data">
            <span class="txt">Email: </span>
            <?php echo $userData[0]['email']?>
            </div>
            <div class="user-data">
            <span class="txt">Date of birth: </span>
            <?php echo $userData[0]['dateOfBirth']?>
            </div>
            <div class="edit"><a href="<?php echo site_url("Home")?>?edit=1">Edit user data</a></div>
            <?php }?>
        </div>
    </div>
    
</div> 
        
        cao!
        
        <?php
        echo validation_errors();
      //$podaci= $this->session->userdata('user')['username'];
      //echo $podaci;
      
      //var_dump($this->session);
        ?>
