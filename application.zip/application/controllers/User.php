<?php

class User extends CI_Controller{
    
    public function editdata(){
        
        $this->load->library ( 'form_validation' );
 
        $this->form_validation->set_rules ( "email", "Email", "trim|required|valid_email");
        $this->form_validation->set_rules ( "user", "Username", "trim|required|min_length[5]|max_length[10]|is_unique[User.username]");
        $this->form_validation->set_rules ( "date", "Date of birth", "trim|required|callback_ageValidation[18]");
        
        if ( $this->form_validation->run () == FALSE ) {
            redirect("Home");
        }else{
        
        $id= $this->session->userdata('user')['idUser'];
        $username= $this->input->post('user');
        $email= $this->input->post('email');
        $date= $this->input->post('date');
        
        $this->load->model("UserModel");
        $this->UserModel->editdata($id, $username, $email, $date);
        redirect("Home");
        }
    }
    
    public function ageValidation ( $string, $minimumAge ) {
        $dateOfBirth = new DateTime ( $string );
        $now = new DateTime ( );
        
        $this->form_validation->set_message ( "ageValidation", "User must at least " . $minimumAge . " years old" );
        
        return $now->diff ( $dateOfBirth )->y > (int) $minimumAge ? true : false;
    }
    
    
    
}




