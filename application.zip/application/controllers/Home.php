<?php


class Home extends CI_Controller{
    
    public function index(){
        $id= $this->session->userdata('user')['idUser'];
        
        $this->load->model('UserModel');
        $userData= $this->UserModel->getdata($id);
        
        
        $data['middle']="middle/homepage";
        $data['middleData']=['userData'=>$userData];
        $this->load->view("basicTemplate", $data);
    }
    
    public function messages(){
        
        $id= $this->session->userdata('user')['idUser'];
        
        $this->load->model('MessagesModel');
        $nazivi= $this->MessagesModel->naziviPoruka($id);
        
        //var_dump($nazivi);
        $data['tip']='conv';
        $data["middle"]="middle/messages"; 
        $data["middleData"] = ["poruke" => $nazivi];
        $this->load->view("basicTemplate", $data);
    }
    
    public function allmessages(){
        
        $id= $this->input->get('id');
        
        $this->load->model('MessagesModel');
        $tekstovi= $this->MessagesModel->svePoruke($id);
        
        //    echo $tekst['content'];
       // }
        // $this->load->view ( "messages", [ "messages" => $tekstovi ] );
        
        
        $this->load->library ( 'parser' );

        $this->parser->parse ( "messages", ["messages" => $tekstovi]);
    }    
    public function sendmessage(){
        
        $msg=$this->input->get('msg');
        $idc=$this->input->get('idc');
        $this->load->model('MessagesModel');
        $this->MessagesModel->posalji($msg, $idc);
        $tekstovi=$this->MessagesModel->svePoruke($idc);
        
        $this->load->library ( 'parser' );
        $this->parser->parse ( "messages", ["messages" => $tekstovi]);

        
        
    }
}
